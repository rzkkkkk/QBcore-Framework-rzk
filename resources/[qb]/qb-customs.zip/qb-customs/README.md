# qb-customs
Vehicle Customization For QB-Core

Make sure to read the locations.lua settings VERY carefully. It has all the information needed to properly setup all your locations. Chances are if something is not working, your configuration for that location is wrong. Doublecheck before opening an issue.

If you are still have having issues, enable the Config.Debug option at the top of config.lua. If you do open an issue, make sure to include all the debug information printed in the f8 menu, along with your Location configuration settings.

# License

    QBCore Framework
    Copyright (C) 2021 Joshua Eger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>
